void Init_golf(void); 
#define RUBY_MAIN_INIT() Init_golf()
#include "main.c"
