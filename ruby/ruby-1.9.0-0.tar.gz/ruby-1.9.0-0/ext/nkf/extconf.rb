require 'mkmf'
create_makefile('nkf')
