
void Init_Fiber_as_Coroutine(void);

void
Init_fiber(void)
{
    Init_Fiber_as_Coroutine();
}
