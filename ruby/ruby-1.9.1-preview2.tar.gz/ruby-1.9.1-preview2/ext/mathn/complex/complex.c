extern void nucomp_canonicalize(int);

void
Init_complex(void)
{
    nucomp_canonicalize(1);
}
