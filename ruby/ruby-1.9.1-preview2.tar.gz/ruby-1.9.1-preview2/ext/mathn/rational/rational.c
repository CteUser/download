extern void nurat_canonicalize(int);

void
Init_rational(void)
{
    nurat_canonicalize(1);
}
